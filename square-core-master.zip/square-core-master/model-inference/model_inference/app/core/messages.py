HTTP_500_DETAIL = "Internal server error."

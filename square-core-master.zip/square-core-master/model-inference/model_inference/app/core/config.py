APP_VERSION = "0.1.0"
APP_NAME = "SQuARE Model Inference API"
API_PREFIX = "/api"
OPENAPI_URL = "/api/openapi.json"

from evaluator.app.core.redis_client import RedisClient
from evaluator.app.mongo.mongo_client import MongoClient

mongo_client = MongoClient()
redis_client = RedisClient()

from square_auth.client_credentials import ClientCredentials

client_credentials = ClientCredentials()

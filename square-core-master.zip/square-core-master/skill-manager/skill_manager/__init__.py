from skill_manager.core.redis_client import RedisClient
from skill_manager.mongo.mongo_client import MongoClient

mongo_client = MongoClient()
redis_client = RedisClient()
